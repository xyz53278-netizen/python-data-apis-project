"""
Python Data & APIs - Data Analysis Application
Loads a CSV dataset, cleans missing values, performs analysis,
creates plots, optionally fetches JSON from a REST API, and writes a report.
"""

from pathlib import Path
import json
import requests
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PLOTS_DIR = BASE_DIR / "plots"
REPORTS_DIR = BASE_DIR / "reports"

for folder in (DATA_DIR, PLOTS_DIR, REPORTS_DIR):
    folder.mkdir(parents=True, exist_ok=True)


def load_dataset(path: Path) -> pd.DataFrame:
    """Load a CSV dataset and give a clear error for missing/empty files."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError("The dataset is empty.")
    return df


def clean_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Remove duplicate rows and fill numeric/text missing values."""
    cleaned = df.copy()
    original_missing = int(cleaned.isna().sum().sum())
    cleaned = cleaned.drop_duplicates()

    for column in cleaned.columns:
        if pd.api.types.is_numeric_dtype(cleaned[column]):
            median = cleaned[column].median()
            cleaned[column] = cleaned[column].fillna(
                median if pd.notna(median) else 0
            )
        else:
            cleaned[column] = cleaned[column].fillna("Unknown")

    return cleaned, original_missing


def analyze_data(df: pd.DataFrame) -> dict:
    """Create a summary with row/column counts and numeric statistics."""
    numeric = df.select_dtypes(include=np.number)
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": list(df.columns),
        "missing_values_after_cleaning": int(df.isna().sum().sum()),
        "numeric_summary": numeric.describe().round(2).to_dict(),
    }


def create_plots(df: pd.DataFrame) -> list[Path]:
    """Save plots for numeric columns and a correlation heatmap when possible."""
    saved = []
    numeric_columns = df.select_dtypes(include=np.number).columns.tolist()

    if numeric_columns:
        for column in numeric_columns:
            plt.figure(figsize=(7, 4))
            sns.histplot(data=df, x=column, kde=True)
            plt.title(f"Distribution of {column}")
            plt.tight_layout()
            output = PLOTS_DIR / f"{column.lower()}_distribution.png"
            plt.savefig(output, dpi=150)
            plt.close()
            saved.append(output)

        if len(numeric_columns) >= 2:
            plt.figure(figsize=(7, 5))
            sns.heatmap(df[numeric_columns].corr(), annot=True, cmap="coolwarm", fmt=".2f")
            plt.title("Numeric Feature Correlation")
            plt.tight_layout()
            output = PLOTS_DIR / "correlation_heatmap.png"
            plt.savefig(output, dpi=150)
            plt.close()
            saved.append(output)

    # If a common marks column exists, generate a readable bar chart.
    marks_col = next((c for c in df.columns if c.lower() in {"marks", "score", "sales", "value"}), None)
    label_col = next((c for c in df.columns if c != marks_col and not pd.api.types.is_numeric_dtype(df[c])), None)
    if marks_col and label_col:
        plot_df = df.head(15)
        plt.figure(figsize=(8, 4))
        sns.barplot(data=plot_df, x=label_col, y=marks_col)
        plt.xticks(rotation=30, ha="right")
        plt.title(f"{marks_col} by {label_col}")
        plt.tight_layout()
        output = PLOTS_DIR / f"{marks_col.lower()}_by_{label_col.lower()}.png"
        plt.savefig(output, dpi=150)
        plt.close()
        saved.append(output)

    return saved


def fetch_api_data(url: str) -> list | dict:
    """Fetch JSON from a REST endpoint with timeout and HTTP error handling."""
    response = requests.get(url, timeout=15)
    response.raise_for_status()
    return response.json()


def write_report(df: pd.DataFrame, summary: dict, plots: list[Path], missing_before: int) -> Path:
    """Write a text report and export the cleaned dataset."""
    cleaned_path = REPORTS_DIR / "cleaned_dataset.csv"
    df.to_csv(cleaned_path, index=False)

    report_path = REPORTS_DIR / "analysis_report.txt"
    lines = [
        "PYTHON DATA ANALYSIS REPORT",
        "=" * 30,
        f"Rows: {summary['rows']}",
        f"Columns: {summary['columns']}",
        f"Column names: {', '.join(summary['column_names'])}",
        f"Missing values before cleaning: {missing_before}",
        f"Missing values after cleaning: {summary['missing_values_after_cleaning']}",
        "",
        "NUMERIC SUMMARY",
        "-" * 30,
        df.select_dtypes(include=np.number).describe().round(2).to_string(),
        "",
        "GENERATED PLOTS",
        "-" * 30,
    ]
    lines.extend(str(path.relative_to(BASE_DIR)) for path in plots)
    lines.extend(["", f"Cleaned dataset: {cleaned_path.relative_to(BASE_DIR)}"])
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def main():
    default_path = DATA_DIR / "sample_students.csv"
    user_path = input(f"CSV path (press Enter for {default_path.relative_to(BASE_DIR)}): ").strip()
    dataset_path = Path(user_path) if user_path else default_path
    if not dataset_path.is_absolute():
        dataset_path = BASE_DIR / dataset_path

    try:
        raw_df = load_dataset(dataset_path)
        cleaned_df, missing_before = clean_dataset(raw_df)
        summary = analyze_data(cleaned_df)
        plots = create_plots(cleaned_df)
        report_path = write_report(cleaned_df, summary, plots, missing_before)

        print("\n--- Analysis Summary ---")
        print(f"Rows: {summary['rows']} | Columns: {summary['columns']}")
        print(f"Missing values before cleaning: {missing_before}")
        print(f"Missing values after cleaning: {summary['missing_values_after_cleaning']}")
        print("\nNumeric statistics:")
        print(cleaned_df.select_dtypes(include=np.number).describe().round(2))
        print(f"\nReport saved to: {report_path}")
        print(f"Cleaned CSV saved to: {REPORTS_DIR / 'cleaned_dataset.csv'}")
        print(f"Plots saved to: {PLOTS_DIR}")

        api_choice = input("\nFetch sample JSON API data too? (y/n): ").strip().lower()
        if api_choice == "y":
            url = "https://jsonplaceholder.typicode.com/users"
            try:
                api_data = fetch_api_data(url)
                api_path = REPORTS_DIR / "api_users.json"
                api_path.write_text(json.dumps(api_data, indent=2), encoding="utf-8")
                print(f"Fetched {len(api_data) if isinstance(api_data, list) else 'JSON'} API response.")
                print(f"API JSON saved to: {api_path}")
            except (requests.RequestException, ValueError) as error:
                print(f"API request failed: {error}")

    except (FileNotFoundError, pd.errors.ParserError, ValueError) as error:
        print(f"Could not analyze dataset: {error}")


if __name__ == "__main__":
    main()
