# Python Data & APIs — Data Analysis Application

A beginner-friendly Python project demonstrating NumPy, Pandas, data cleaning, Matplotlib/Seaborn visualizations, REST API requests, JSON processing, and automated report generation.

## Features
- Load CSV datasets with Pandas
- Detect and handle missing values
- Remove duplicate records
- Calculate descriptive statistics with Pandas and NumPy
- Generate distribution charts and a correlation heatmap
- Consume a REST API using `requests`
- Save a cleaned CSV, text analysis report, charts, and optional API JSON output

## Tech Stack
Python · NumPy · Pandas · Matplotlib · Seaborn · Requests · REST API · JSON

## Project Structure
```text
python-data-apis-project/
├── data/
│   └── sample_students.csv
├── plots/                 # Generated charts
├── reports/               # Generated report and cleaned data
├── main.py
├── requirements.txt
└── README.md
```

## Setup
Python 3.10+ recommended.

```bash
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install dependencies and run:

```bash
python -m pip install -r requirements.txt
python main.py
```

Press Enter to use the included sample dataset. When asked, enter `y` to fetch JSON data from the public JSONPlaceholder users API. An internet connection is required for the API step.

## Output
- `reports/analysis_report.txt` — summary report
- `reports/cleaned_dataset.csv` — cleaned dataset
- `reports/api_users.json` — optional API response
- `plots/` — generated visualizations

## Concepts Practiced
- NumPy arrays and statistical functions
- Pandas DataFrames, filtering, missing-value handling, and descriptive statistics
- Matplotlib/Seaborn plotting
- HTTP GET requests, status-code checking, timeouts, and JSON parsing
- Functions, exceptions, file paths, and report generation

## Notes
This is an educational project. The included sample dataset is synthetic. API availability depends on the external service and internet connection. Avoid uploading private or sensitive datasets to public repositories.

## Author
Kamal Dhaka
